//Java Program to print the elements of an array

public class m5

{    
public static void main(String args[])  
{    
//declaration and instantiation of an array  
int arr[]=new int[4];     
//initializing elements   
arr[0]=10;  
arr[1]=20;    
arr[2]=70;    
arr[3]=40;    
//traversing over array using for loop  
for(int i=0;i<arr.length;i++)    //length is the property of the array  
System.out.println(arr[i]);    
}  
}    