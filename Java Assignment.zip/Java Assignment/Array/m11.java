//Java Program to print the number of elements present in an array

public class m11 {  
    public static void main(String[] args) {  
      //Initialize array  
        int [] arr = new int [] {1, 2, 3, 4, 5};  
      //Number of elements present in an array can be found using the length  
        System.out.println("Number of elements present in given array: " + arr.length);  
    }  
}  